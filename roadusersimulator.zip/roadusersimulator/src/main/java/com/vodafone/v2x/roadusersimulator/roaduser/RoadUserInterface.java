package com.vodafone.v2x.roadusersimulator.roaduser;

public interface RoadUserInterface {

    public void activate();
    public void suspend();
    public void setAnimation(boolean request);

}
